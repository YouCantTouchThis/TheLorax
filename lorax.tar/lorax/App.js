import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Camera } from 'expo-camera';
const axios = require('axios').default;

import * as tf from '@tensorflow/tfjs';


export default function App() {
    const [hasPermission, setHasPermission] = useState(null);
    const [type, setType] = useState(Camera.Constants.Type.back);
    const [nav, setNav] = useState('tutorial');
    // nav states: tutorial, camera, output
    const [pred, setPred] = useState({
        'species': null, 'disease': null
    });
    const [camera, setCamera] = useState(null);

    useEffect(() => {
        (async () => {
            const { status } = await Camera.requestPermissionsAsync();
            setHasPermission(status === 'granted');
        })();
    }, []);

    if (hasPermission === null) {
        return <View />;
    }
    if (hasPermission === false) {
        return <Text>No access to camera</Text>;
    }
    if (nav == 'tutorial') {
        return (
            <View style={styles.container}>
                <Text style={styles.title}>Lorax</Text>
                <Text style={styles.paragraph}>Take a picture of a tree's leaf and help conservation researchers everywhere.</Text>
                <Text style={styles.quote}>"I am the Lorax, I speak for the trees"</Text>
                <TouchableOpacity style={styles.startButton} onPress={() => {setNav('camera')}}>
                    <Text style={styles.startButtonText}>Get Started</Text>
                </TouchableOpacity>
            </View>
        );
    } if (nav == 'camera') {
        return (
            <View style={styles.cameraContainer}>
                <Camera
                    style={styles.camera}
                    type={type}
                    ratio="16:9"
                    ref={(ref) => {
                        setCamera(ref);
                    }} >
                    <View style={styles.buttonContainer}>
                        <TouchableOpacity
                            style={styles.button}
                            onPress={() => {onCapture(setPred, setNav, camera)}} />
                    </View>
                </Camera>
            </View>
        );
    } if (nav == 'output') {
        if (pred['species'] == null) {
            return (
                <View style={styles.container}>
                    <ActivityIndicator style={styles.activity} size={100} color="#000000" />
                </View>
            );
        } else {
            return (
                <View style={styles.container}>
                    <Text style={[styles.title, {marginTop: 100}]}>{ pred['species'] }</Text>
                    <Text style={styles.scrapbook}>Added to scrapbook</Text>
                    <TouchableOpacity style={styles.backButton} onPress={() => {
                        setNav('camera');
                        setPred({'species': null, 'disease': null});
                    }}>
                        <Text style={styles.startButtonText}>Back to Camera</Text>
                    </TouchableOpacity>
                </View>
            );
        };
    }
}

async function onCapture(setPred, setNav, camera) {
    console.log('captured');
    let image = await camera.takePictureAsync()['base64'];

    setNav('output'); // navigate to output

    // make prediction from model
    const path = `file://D:/Aditya/SHS_Hacks_2021/lorax/training_2/training_2/model.json`;

    const model = await tf.loadGraphModel(path);

    console.log(`model: ${model}`);

    const t = tf.tensor(image);

    const prediction = model.predict(t);
    
    let pred = { species: prediction.toString(), disease: null };  
    setPred(pred); // set predictions in state
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
    },
    cameraContainer: {
        flex: 1,
    },
    camera: {
        flex: 1,
    },
    title: {
        fontSize: 60,
        fontWeight: 'bold',
        marginTop: 50,
        textAlign: 'center',
    },
    paragraph: {
        fontSize: 20,
        textAlign: 'center',
        marginTop: 38,
        lineHeight: 40,
        marginHorizontal: 30,
    },
    quote: {
        fontSize: 30,
        fontStyle: 'italic',
        textAlign: 'center',
        marginTop: 38,
        lineHeight: 40,
        marginHorizontal: 30,
    },
    startButton: {
        marginTop: 200,
        borderWidth: 2,
        borderRadius: 20,
        paddingHorizontal: 80,
        paddingVertical: 20,
    },
    scrapbook: {
        fontSize: 30,
        marginTop: 20,
        color: 'green',
        fontStyle: 'italic',
    },
    backButton: {
        marginTop: 300,
        borderWidth: 2,
        borderRadius: 20,
        paddingHorizontal: 80,
        paddingVertical: 20,
    },
    startButtonText: {
        fontSize: 25,
        fontWeight: 'bold',
    },
    buttonContainer: {
        flex: 1,
        backgroundColor: 'transparent',
        flexDirection: 'row',
        margin: 20,
        justifyContent: 'center',
    },
    button: {
        borderWidth: 10,
        alignSelf: 'flex-end',
        width: 80,
        height: 80,
        borderRadius: 20,
        borderColor: 'white',
    },
    text: {
        fontSize: 18,
        color: 'white',
        borderWidth: 3,
        width: '100%',
    },
    activity: {
        marginTop: 150
    }
});
